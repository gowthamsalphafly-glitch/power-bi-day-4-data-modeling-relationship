num1 = int(input("enter first number:"))
num2 = int(input("enter second number:"))

print("addition:" , num1 + num2)
print("subtraction:" , num1 - num2)
print("multiplication:" , num1 * num2)
print("division:" , num1 / num2)
print("floor division:" , num1 // num2)
print("modulus:" , num1 % num2)
print("exponentiation:" , num1 ** num2)

num = int(input("enter a number: "))

if num % 2 == 0:
  print("even")
else:
  print("odd")

marks = int(input("enter your marks: "))
if marks  >= 90:
  print("grade: A+")
elif marks >= 70:
  print("grade: A") 
elif marks >= 60:
  print("grade: B")
elif marks >= 45:
  print("grade: C")
else:
  print ("grade: F")
  
  





      


10
